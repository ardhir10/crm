declare const _default: () => void;
export default _default;
