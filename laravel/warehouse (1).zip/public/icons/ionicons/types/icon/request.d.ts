export declare const getSvgContent: (url: string) => Promise<string>;
