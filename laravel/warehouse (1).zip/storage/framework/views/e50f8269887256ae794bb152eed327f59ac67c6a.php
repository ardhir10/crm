<?php $__env->startSection('page_title',$page_title); ?>

<?php $__env->startSection('css'); ?>
<style>
    a {
        color: inherit;
    }

    .card__one {
        transition: transform .5s;


    }

    .card__one::after {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        transition: opacity 2s cubic-bezier(.165, .84, .44, 1);
        box-shadow: 0 8px 17px 0 rgba(0, 0, 0, .2), 0 6px 20px 0 rgba(0, 0, 0, .15);
        content: '';
        opacity: 0;
        z-index: -1;
    }

    .card__one:hover,
    .card__one:focus {
        transform: scale3d(1.036, 1.036, 1);
        -webkit-box-shadow: -1px -1px 16px -4px rgba(0, 0, 0, 0.53);
        -moz-box-shadow: -1px -1px 16px -4px rgba(0, 0, 0, 0.53);
        box-shadow: -1px -1px 16px -4px rgba(0, 0, 0, 0.53);


    }



    a:hover {
        color: inherit;
        text-decoration: none;
        cursor: pointer;
    }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="br-mainpanel" id="app">
    <div class="br-pageheader">
        <div>
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
                <span class="breadcrumb-item "><?php echo e($page_title); ?></span>
                <span class="breadcrumb-item "><?php echo e($project->name); ?></span>
                <span class="breadcrumb-item active">Create</span>

            </nav>

        </div>
    </div><!-- br-pageheader -->


    <div class="br-pagebody">



        <div class="row">
            <div class="  col-lg-4">
                <div class="card shadow-base bd-0  card__one mg-b-20 rounded-20">
                    <div class="card-header bg-transparent d-flex justify-content-between align-items-center">
                        <h6 class="card-title tx-uppercase tx-12 mg-b-0">Create PR for Project <?php echo e($project->name); ?></h6>
                    </div><!-- card-header -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <form action="<?php echo e(url($base_route)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                    <div class="form-group">
                                        <label for="">PR Number</label>
                                        <div>
                                            <input type="text" autocomplete="off"
                                                oninput="this.value = this.value.toUpperCase()" v-model="pr_number"
                                                name="pr_number"
                                                class="form-control<?php echo e($errors->has('pr_number') ? ' is-invalid' : ''); ?>" readonly>
                                            {{pr_number}}

                                            <input type="hidden" autocomplete="off"
                                                oninput="this.value = this.value.toUpperCase()" v-model="prNumberCheck"
                                                name="pr_number_check"
                                                class="form-control<?php echo e($errors->has('pr_number') ? ' is-invalid' : ''); ?>">

                                                
                                            <input type="hidden" autocomplete="off" name="project_number"
                                                value="<?php echo e($project->project_number); ?>">

                                        </div>
                                        <?php if($errors->has('pr_number')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('pr_number')); ?></small>
                                        <?php endif; ?>
                                    </div>


                                    <div class="form-group">
                                        <button class="btn btn-success btn-sm">Save</button>
                                        <a href="<?php echo e(url($base_route.'/'.$project->id)); ?>">
                                            <button type="button" class="btn btn-danger btn-sm">Back</button>
                                        </a>

                                    </div>
                                </form>

                            </div>



                        </div>

                    </div><!-- card-body -->
                </div><!-- card -->
            </div>
            







</div>


</div><!-- br-pagebody -->

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->\


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var route_url = '<?php echo e($base_route); ?>';

    var vm = new Vue({
        el: '#app',
        data: {
            pr_number: '<?php echo e($pr_number); ?>'
        },
        computed: {
            prNumberCheck: function () {
                // `this` points to the vm instance
                return this.pr_number
            }
        }
    })

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>