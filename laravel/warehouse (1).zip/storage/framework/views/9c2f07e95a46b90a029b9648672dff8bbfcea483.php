<div class="br-logo"><a href="#"><span>[</span>Jakarta <i>Process</i><span>]</span></a></div>
    <div class="br-sideleft sideleft-scrollbar">
        <label class="sidebar-label pd-x-10 mg-t-20 op-3">Navigation</label>
        <ul class="br-sideleft-menu">
            <li class="br-menu-item">
                <a href="<?php echo e(url('dashboard')); ?>" class="br-menu-link ">
                    <i class="menu-item-icon icon ion-ios-home-outline tx-24"></i>
                    <span class="menu-item-label">Dashboard</span>
                </a><!-- br-menu-link -->
            </li><!-- br-menu-item -->
           
            <li class="br-menu-item">
                <a href="#" class="br-menu-link with-sub">
                    <i class="menu-item-icon icon ion-folder tx-20"></i>
                    <span class="menu-item-label">Master Data</span>
                </a><!-- br-menu-link -->
                <ul class="br-menu-sub">
                    <li class="sub-item"><a href="<?php echo e(url('departements')); ?>" class="sub-link">Departements</a></li>
                    <li class="sub-item"><a href="<?php echo e(url('users')); ?>" class="sub-link">Users</a></li>
                    <li class="sub-item"><a href="<?php echo e(url('items')); ?>" class="sub-link">Items</a></li>
                </ul>
            </li>
            
        </ul><!-- br-sideleft-menu -->

        <label class="sidebar-label pd-x-10 mg-t-25 mg-b-20 tx-info">Information Summary</label>

         
        <br>
    </div><!-- br-sideleft -->