<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


    <title>Login Page - <?php echo e(config('app.name')); ?></title>

    <!-- vendor css -->
    <link href="<?php echo e(asset('backend/')); ?>/lib/%40fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('backend/')); ?>/lib/ionicons/css/ionicons.min.css" rel="stylesheet">

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('backend/')); ?>/css/bracket.css">
</head>

<body>

    <div class="d-flex align-items-center justify-content-center ht-100v">
        <video id="headVideo" class="pos-absolute a-0 wd-100p ht-100p object-fit-cover" autoplay muted loop>
            <source src="<?php echo e(asset('videos/video4.mp4')); ?>" type="video/mp4">
            <source src="<?php echo e(asset('videos/video1.ogv')); ?>" type="video/ogg">
            <source src="<?php echo e(asset('videos/video1.webm')); ?>" type="video/webm">
        </video><!-- /video -->
        <div class="overlay-body bg-black-7 d-flex align-items-center justify-content-center">
            <div class="login-wrapper wd-300 wd-xs-350 pd-25 pd-xs-40 rounded bg-black-6">
                <div class="signin-logo tx-center tx-18 tx-bold tx-white"><span class="tx-normal">[</span> Jakarta
                    Process <span class="tx-info">Automation</span> <span class="tx-normal">]</span></div>
                <div class="tx-white-5 tx-center mg-b-60">Warehouse System Information</div>
                    <?php if(session()->has('validate')): ?>
                    <span class="text-danger" role="alert">
                        <strong><?php echo e(session()->get('validate')); ?></strong>
                    </span>
                    
                    <?php endif; ?>
                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?> fc-outline-dark" name="email" value="<?php echo e(old('email')); ?>" placeholder="Enter your Email" required autofocus >

                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        
                    </div><!-- form-group -->
                    <div class="form-group">
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>  fc-outline-dark" name="password" placeholder="Enter your password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        
                        <a href="#" class="tx-info tx-12 d-block mg-t-10">Forgot password?</a>
                    </div><!-- form-group -->

                    <div class="form-group row">
                            <div class="col-md-6  ">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>
                    <button type="submit" class="btn btn-info btn-block">Sign In</button>

                    
                </form>

            </div><!-- login-wrapper -->
        </div><!-- overlay-body -->
    </div><!-- d-flex -->

    <script src="<?php echo e(asset('backend/')); ?>/lib/jquery/jquery.min.js"></script>
    <script src="<?php echo e(asset('backend/')); ?>/lib/jquery-ui/ui/widgets/datepicker.js"></script>
    <script src="<?php echo e(asset('backend/')); ?>/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
        $(function () {
            'use strict';

            // Check if video can play, and play it
            var video = document.getElementById('headVideo');
            video.addEventListener('canplay', function () {
                video.play();
            });

        });

    </script>

</body>

</html>
