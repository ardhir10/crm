<?php $__env->startSection('page_title',$page_title); ?>


<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
            <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
            <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>
        </nav>
    </div><!-- br-pageheader -->
    

<div class="br-pagebody">

     
 

    <div class="row   mg-b-20">


        <div class="col-lg-12">
            <h6 class="card-title"><?php echo e($page_title); ?></h6>
            <div class="card">
               
                <div class="card-header">
                        
                <a href="<?php echo e(url($base_route.'/wip/create')); ?>">
                                <button class="btn btn-sm  float-right btn-info"><i
                                    class="icon ion ion-ios-plus-outline"></i> New data</button>
                        </a>
                </div><!-- card-header -->
                <div class="card-body">
                    <div class="table-wrapper">
                        <table class="table " id="datatable1">
                            <thead>
                                <th>No</th>
                                
                                <th>Number</th>
                                
                                <th>Date</th>
                                <th>Project</th>
                                <th>Request By</th>
                                <th>Approve By</th>
                                <th> items</th>
                            </thead>
                            <tbody>
                                <?php
                                $no=1;
                                ?>
                                <?php $__currentLoopData = $last_po; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    
                                    <td>
                                        <a href="<?php echo e(url('warehouse/purchase-orders/'.$lpo->id.'/items')); ?>">
                                            <p class="mg-b-0"><?php echo e($lpo->po_number); ?></p>
                                        </a>
                                    </td>
                                    
                                    <td> <a
                                            href="<?php echo e(url('purchase-requisitions/'.$lpo->pr->id.'/items')); ?>"><?php echo e($lpo->pr->pr_number); ?></a>
                                    </td>
                                    <td>
                                        <?php echo e($lpo->delivered_at); ?>

                                    </td>

                                    <td>
                                        <?php echo e($lpo->warehouse_at); ?>

                                    </td>
                                  
                                    <td>
                                        <?php echo e($lpo->items()->count()); ?>

                                    </td>
                                    <td>
                                        <small><?php echo e($lpo->pr->project->project_number); ?></small>
                                        <br>
                                        <?php echo e($lpo->pr->project->name); ?>

                                    </td>



                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                    
                </div>
            </div>
        </div>

    </div>



    


</div><!-- br-pagebody -->
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        var route_url = '<?php echo e(url($base_route)); ?>';


    });

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>