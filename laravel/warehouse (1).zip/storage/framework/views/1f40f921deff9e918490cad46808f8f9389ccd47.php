<?php $__env->startSection('page_title',$page_title); ?>


<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <div>
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
                <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>

            </nav>

        </div>
    </div><!-- br-pageheader -->


    <div class="br-pagebody">

        <div class="row">

            <div class="col-lg-12 mg-b-20">
                <div class="br-section-wrapper" style="padding: 30px 20px">
                    <div style="align">
                        <span class="tx-bold tx-18"><i class="icon ion ion-ios-box tx-22"></i> <?php echo e($page_title); ?></span>
                        <a href="<?php echo e(url($base_route.'/create')); ?>">
                            <button class="btn btn-sm btn-info float-right"><i
                                    class="icon ion ion-ios-plus-outline"></i>
                                New
                                Data</button>
                        </a>
                    </div>
                    <hr>
                    <?php if(session()->has('create')): ?>
                    <div class="alert alert-success wd-50p">
                        <?php echo e(session()->get('create')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('update')): ?>
                    <div class="alert alert-warning wd-50p">
                        <?php echo e(session()->get('update')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>


                    <?php if(session()->has('delete')): ?>
                    <div class="alert alert-danger wd-50p">
                        <?php echo e(session()->get('delete')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>
                    <div class="table-wrapper ">
                        <table class="table display  nowrap" id="table">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>DESCRIPTION</th>
                                    <th>DATE</th>
                                    <th>TYPE</th>
                                    <th>MFG</th>
                                    <th>QTY</th>
                                    <th>UNIT</th>
                                    <th>PRICE</th>
                                    <th>DISC</th>
                                    <th>TOTAL COST</th>
                                    <th>DESCRIPTION</th>
                                    <th width="15%">Action</th>
                                </tr>
                            </thead>
                            

                        </table>
                    </div>
                    
                </div>

            </div>

        </div>

    </div><!-- br-pagebody -->

    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->\

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var route_url = '<?php echo e($base_route); ?>';

    $(function () {

        $('#table').DataTable({
            responsive: true,
            language: {
                searchPlaceholder: 'Search...',
                sSearch: '',
                lengthMenu: '_MENU_ items/page',
            },
            processing: true,
            serverSide: true,
            ajax: {
                url: '<?php echo e($base_route); ?>/json',
                data: function (outData) {
                    // what is being sent to the server
                    // console.log(outData);
                    return outData;
                },
                dataFilter: function (inData) {
                    // what is being sent back from the server (if no error)
                    // console.log(inData);
                    return inData;
                },
                error: function (err, status) {
                    // what error is seen(it could be either server side or client side.
                    // console.log(err);
                },
            },
            columns: [

                {
                    data: "DT_RowIndex",
                    name: 'DT_RowIndex'

                    // render: function (data, type, row, meta) {
                    //     return meta.row + meta.settings._iDisplayStart + 1 +
                    //         '<span style="display:none">' + data + '</span>';
                    //     // return ;
                    // }
                },
                {
                    data: 'description',

                    render: function (data, type, full, meta) {
                        return fn(data,10) ;
                    },
                },
                {
                    data: 'created_at',
                    name: 'created_at'
                },
                {
                    data: 'type',
                    name: 'type'
                },
                {
                    data: 'mfg',
                    name: 'mfg'
                },
                {
                    data: 'qty',
                    name: 'qty'
                },
                {
                    data: 'unit',
                    name: 'unit'
                },
                {
                    data: 'price',
                    render: $.fn.dataTable.render.number(',', '.', 0, 'Rp. '),
                    name: 'price'
                },
                {
                    data: 'disc',
                    name: 'disc'
                },
                {
                    data: 'total_cost',
                    render: $.fn.dataTable.render.number(',', '.', 0, 'Rp. '),
                    name: 'total_cost'
                },
                {
                    data: 'description',
                    name: 'description'
                },
                {
                    data: 'id',
                    name: 'button',
                    render: function (data, type, full, meta) {
                        return `<a href="<?php echo e(url($base_route.'/` + data + `/edit/')); ?>">
                                <button class="btn btn-warning btn-sm text-white">
                                    <i class="icon icon ion ion-edit"></i> Edit

                                </button>
                            </a>
                            <button class="btn btn-danger btn-sm text-white"
                                onclick="deleteData(` + data + `)">
                                <i class="icon icon ion ion-ios-trash-outline"></i> Delete
                            </button>`;
                    },
                    orderable: false
                },
            ],


        });

        function fn(text, count){
    return text.slice(0, count) + (text.length > count ? "..." : "");
}
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>