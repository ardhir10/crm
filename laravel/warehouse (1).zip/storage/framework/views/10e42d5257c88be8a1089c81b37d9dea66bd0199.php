<?php $__env->startSection('page_title',$page_title); ?>

<?php $__env->startSection('css'); ?>
<style>
    a {
        color: inherit;
    }

    .card__one {
        transition: transform .5s;


    }

    .card__one::after {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        transition: opacity 2s cubic-bezier(.165, .84, .44, 1);
        box-shadow: 0 8px 17px 0 rgba(0, 0, 0, .2), 0 6px 20px 0 rgba(0, 0, 0, .15);
        content: '';
        opacity: 0;
        z-index: -1;
    }

    .card__one:hover,
    .card__one:focus {
        transform: scale3d(1.036, 1.036, 1);
        -webkit-box-shadow: -1px -1px 16px -4px rgba(0, 0, 0, 0.53);
        -moz-box-shadow: -1px -1px 16px -4px rgba(0, 0, 0, 0.53);
        box-shadow: -1px -1px 16px -4px rgba(0, 0, 0, 0.53);


    }



    a:hover {
        color: inherit;
        text-decoration: none;
        cursor: pointer;
    }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <div>
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
                <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>

            </nav>

        </div>
    </div><!-- br-pageheader -->


    <div class="br-pagebody">

        <div class="row  mg-b-20">
            <div class="col-lg-4 ">
                <div class="br-section-wrapper  rounded-20 mg-b-20" style="padding: 30px 20px">
                    <div style="align">
                        <span class="tx-bold tx-18"><i class="icon ion ion-clipboard tx-22"></i> <?php echo e($page_title); ?></span>
                        
                    </div>
                    <hr>
                    <?php if(session()->has('create')): ?>
                    <div class="alert alert-success wd-100p">
                        <?php echo e(session()->get('create')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('update')): ?>
                    <div class="alert alert-warning wd-100p">
                        <?php echo e(session()->get('update')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>


                    <?php if(session()->has('delete')): ?>
                    <div class="alert alert-danger wd-100p">
                        <?php echo e(session()->get('delete')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-lg-12">
                            <form action="" method="get">
                                <div class="form-group">
                                    
                                    <div class="input-group    transition">
                                        <input id="searchbox" type="text" class="form-control"
                                            placeholder="Search Project" name="project">
                                        <span class="input-group-btn">
                                            <button class="btn btn-info" type="submit"><i
                                                    class="fas fa-search"></i></button>
                                        </span>
                                    </div>
                                </div>
                            </form>

                        </div>
                    </div>

                    
                </div>

            </div>

            <div class="col-lg-8">
                <div class="br-section-wrapper  rounded-20 mg-b-20" style="padding: 30px 20px">

                    <div class="row">
                        <div class="col-lg-4 ">
                            <div class="card card-body tx-white-8 bg-dance bd-0 rounded-10 mg-b-20">
                                <div class="  d-flex align-items-center">
                                    
                                    <img src="<?php echo e(asset('icons/other/icons8_purchase_order_64px_1.png')); ?>"
                                        class="img-fluid" alt="">

                                    <div class="mg-l-20">
                                        <p
                                            class="tx-10 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">
                                            Total PR</p>
                                        <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1">
                                            <?php echo e($purchase_requisition->count()); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 ">
                            <div class="card card-body tx-white-8 bg-teal bd-0 rounded-10 mg-b-20">
                                <div class="  d-flex align-items-center">
                                    
                                    <img src="<?php echo e(asset('icons/other/icons8_checked_64px.png')); ?>" class="img-fluid">

                                    <div class="mg-l-20">
                                        <p
                                            class="tx-10 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">
                                            Approved PR</p>
                                        <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1">
                                            <?php echo e($purchase_requisition_approved->count()); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 ">
                            <div class="card card-body tx-white-8 bg-danger bd-0 rounded-10 mg-b-20">
                                <div class="  d-flex align-items-center">
                                    
                                    <img src="<?php echo e(asset('icons/other/icons8_cancel_2_64px.png')); ?>" class="img-fluid"
                                        alt="">

                                    <div class="mg-l-20">
                                        <p
                                            class="tx-10 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">
                                            Canceled PR</p>
                                        <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1">
                                            <?php echo e($purchase_requisition_canceled->count()); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </div>
        

        <div class="row">
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6  col-lg-3">
                <a href="<?php echo e(url($base_route.'/'.$project->id)); ?>">
                    <div class="card shadow-base bd-0  card__one mg-b-20 rounded-20">
                        <div class="card-header bg-mantle d-flex justify-content-between align-items-center"
                            style=" border-radius: 122px;border-bottom-left-radius: 0px;">
                            <h6 class="card-title text-white tx-uppercase tx-12 mg-b-0"><?php echo e($project->name); ?></h6>
                            <span
                                class="tx-12 text-white tx-uppercase"><?php echo e(date('d M Y',strtotime($project->created_at))); ?></span>
                        </div><!-- card-header -->
                        <div class="card-body">
                            <p class="tx-sm tx-inverse tx-medium mg-b-0"><?php echo e($project->customer['name']); ?></p>
                            <p class="tx-12"><?php echo e($project->project_number); ?></p>
                            <p class="tx-12"><?php echo e($project->description); ?></p>
                            <div class="row align-items-center">
                                
                                <?php if($project->pr()->get()->count() == 0): ?>
                                <?php
                                $badge = 'badge-danger';
                                ?>
                                <?php else: ?>
                                <?php
                                $badge = 'badge-info';
                                ?>
                                <?php endif; ?>


                                <?php if($project->items()->get()->count() == 0): ?>
                                <?php
                                $badge_it = 'badge-danger';
                                ?>
                                <?php else: ?>
                                <?php
                                $badge_it = 'badge-info';
                                ?>
                                <?php endif; ?>



                                <div class="col-12">
                                    <span class="badge <?php echo e($badge); ?>"> <?php echo e($project->pr()->get()->count()); ?></span> PR in
                                    Project
                                </div><!-- col-9 -->
                                
                                <div class="col-12">
                                    <span class="badge <?php echo e($badge_it); ?>"> <?php echo e($project->items()->get()->count()); ?></span>
                                    Items
                                    in Project
                                </div><!-- col-9 -->
                                <div class="col-12">
                                    <div style="text-align:right ">
                                        <i class="icon fa fa-thumbs-up text-success">
                                            <?php echo e($project->pr()->where('status',1)->get()->count()); ?></i>
                                        <i class="icon fa fa-thumbs-down text-danger">
                                            <?php echo e($project->pr()->where('status',0)->get()->count()); ?></i>
                                    </div>
                                </div><!-- col-9 -->
                            </div><!-- row -->
                            
                            
                        </div><!-- card-body -->
                    </div><!-- card -->
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





        </div>
        <div style="display:block">
            <?php echo e($projects->links()); ?>

        </div>

    </div><!-- br-pagebody -->

    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->\


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var route_url = '<?php echo e($base_route); ?>';

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>