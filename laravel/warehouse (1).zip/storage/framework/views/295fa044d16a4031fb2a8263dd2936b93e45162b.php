<?php $__env->startSection('page_title',$page_title); ?>
<style>
    .dataTables_wrapper .dataTables_processing {
        position: absolute;
        top: 0% !important;
        left: 50% !important;
        width: 100% !important;
        height: 90% !important;
        margin-left: -20%;
        margin-top: -25px;
        padding-top: 20px;
        text-align: center;
        font-size: 1.2em;
        background: #ffffff7a !important;
        z-index: 9999;
    }

    .center-vh {
        margin: auto;
        width: 50%;
        border: 3px solid green;
        padding: 10px;
    }

</style>



<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <div>
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
                <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>

            </nav>

        </div>
    </div><!-- br-pageheader -->


    <div class="br-pagebody">

        <div class="row">

            <div class="col-lg-12 mg-b-20">
                <div class="br-section-wrapper" style="padding: 30px 20px">
                    <div style="align">
                        <span class="tx-bold tx-18"><i class="icon ion ion-ios-box tx-22"></i> <?php echo e($page_title); ?></span>
                        <a href="<?php echo e(url($base_route.'/create')); ?>">
                            <button class="btn btn-sm btn-info float-right"><i
                                    class="icon ion ion-ios-plus-outline"></i>
                                New
                                Data</button>
                        </a>

                        <button class="btn btn-sm btn-success mg-r-10 float-right" data-toggle="modal"
                            data-target="#modaldemo1">
                        <img src="<?php echo e(asset('icons/other/icons8_ms_excel_filled_12px.png')); ?>" class="img-fluid" alt="">
                            
                            
                            Import Excel</button>

                        <input type="button" id="delete_value" class="btn btn-sm btn-danger mg-r-10 float-right" name="save_value" value="Delete Selected" />

                        
                    </div>
                    <hr>
                    <?php if(session()->has('create')): ?>
                    <div class="alert alert-success wd-50p">
                        <?php echo e(session()->get('create')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('update')): ?>
                    <div class="alert alert-warning wd-50p">
                        <?php echo e(session()->get('update')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>


                    <?php if(session()->has('delete')): ?>
                    <div class="alert alert-danger wd-50p">
                        <?php echo session()->get('delete'); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <div class="table-wrapper ">

                        <table class="table display  nowrap" id="table">
                            <thead>
                                <tr>

                                    <th>NO</th>
                                    <th style="" width="1%">
                                        <button type="button" id='selectAll' class="btn btn-sm btn-info"> <i
                                                class="ion ion-android-checkbox-outline"></i></button>
                                        Select This Page
                                        
                                    </th>
                                    <th>DESCRIPTION</th>
                                    <th>DATE</th>
                                    <th>TYPE</th>
                                    <th>MFG</th>
                                    <th>QTY</th>
                                    <th>UNIT</th>
                                    <th>PRICE</th>
                                    <th>DISC</th>
                                    <th>TOTAL COST</th>
                                    <th width="15%">Action</th>
                                    <th>DESCRIPTION</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                                <tr>

                                    <th>NO</th>
                                    <th style="" width="1%">
                                    </th>
                                    <th>DESCRIPTION</th>
                                    <th>DATE</th>
                                    <th>TYPE</th>
                                    <th>MFG</th>
                                    <th>QTY</th>
                                    <th>UNIT</th>
                                    <th>PRICE</th>
                                    <th>DISC</th>
                                    <th>TOTAL COST</th>
                                    <th width="15%">Action</th>
                                    <th>DESCRIPTION</th>
                                </tr>
                            </tfoot>
                            

                        </table>
                    </div>
                    
                </div>

            </div>

        </div>

    </div><!-- br-pagebody -->

    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->\

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
    <?php echo csrf_field(); ?>
</form>

<!-- ADD ITEM MODAL -->
<div id="modaldemo1" class="modal fade">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content bd-0 tx-14">
            
            <form action="<?php echo e(url('/impor/import_excel')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="modal-body pd-25">
                    <div class="form-group">
                        <label for="">Upload Excel :</label>
                        <input type="file" name="file" class="form-control">
                    </div>
                        
                        <a href="<?php echo e(url('/download/SampleImportItems.xlsx')); ?>"><img src="<?php echo e(asset('icons/other/icons8_ms_excel_25px.png')); ?>" class="img-fluid" alt="">
                        Download sample file</a>
                </div>
                <div class=" modal-footer">
                    <button class="btn btn-sm btn-success tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                        type="submit">Import</button>
                    <button type="button"
                        class="btn btn-sm btn-secondary tx-11 tx-uppercase pd-y-12 pd-x-25 tx-mont tx-medium"
                        data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div><!-- modal-dialog -->
</div><!-- modal -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var route_url = '<?php echo e($base_route); ?>';

    $(function () {

        var table = $('#table').DataTable({
            responsive: true,
            language: {
                searchPlaceholder: 'Search...',
                sSearch: '',
                lengthMenu: '_MENU_ items/page',
            },
            language: {
                processing: '<div class="" style="position: relative;top: 41%;"><i class="fa fa-spinner fa-spin fa-3x fa-fw mg-t-20"></i><span class="sr-only">Loading...</span></div> '
            },
            // stateSave: true,
            processing: true,
            serverSide: true,
            ajax: {
                url: '<?php echo e($base_route); ?>/json',
                data: function (outData) {
                    // what is being sent to the server
                    // console.log(outData);
                    return outData;
                },
                dataFilter: function (inData) {
                    // what is being sent back from the server (if no error)
                    // console.log(inData);
                    return inData;
                },
                error: function (err, status) {
                    // what error is seen(it could be either server side or client side.
                    // console.log(err);
                },
            },
            columns: [


                {
                    data: "DT_RowIndex",
                    name: 'DT_RowIndex'

                    // render: function (data, type, row, meta) {
                    //     return meta.row + meta.settings._iDisplayStart + 1 +
                    //         '<span style="display:none">' + data + '</span>';
                    //     // return ;
                    // }
                },
                {
                    data: 'id',
                    name: 'checkbox',
                    render: function (data, type, full, meta) {
                        return `<input name="selector[]" class="item-checkbox checkItem" type="checkbox"  value="` +
                            data + `" >`;
                    },
                    orderable: false
                },
                {
                    data: 'description',

                    render: function (data, type, full, meta) {
                        return fn(data, 10);
                    },
                },
                {
                    data: 'created_at',
                    name: 'created_at'
                },
                {
                    data: 'type',
                    name: 'type'
                },
                {
                    data: 'mfg',
                    name: 'mfg'
                },
                {
                    data: 'qty',
                    name: 'qty'
                },
                {
                    data: 'unit',
                    name: 'unit'
                },
                {
                    data: 'price',
                    render: $.fn.dataTable.render.number(',', '.', 0, 'Rp. '),
                    name: 'price'
                },
                {
                    data: 'disc',
                    name: 'disc'
                },

                {
                    data: 'total_cost',
                    render: $.fn.dataTable.render.number(',', '.', 0, 'Rp. '),
                    name: 'total_cost'
                },
                {
                    data: 'id',
                    name: 'button',
                    render: function (data, type, full, meta) {
                        return `<a href="<?php echo e(url($base_route.'/` + data + `/edit/')); ?>">
                                <button class="btn btn-warning btn-sm text-white">
                                    <i class="icon icon ion ion-edit"></i> Edit

                                </button>
                            </a>
                            <button class="btn btn-danger btn-sm text-white"
                                onclick="deleteData(` + data + `)">
                                <i class="icon icon ion ion-ios-trash-outline"></i> Delete
                            </button>`;
                    },
                    orderable: false
                },
                {
                    data: 'description',
                    name: 'description'
                },

            ],


        });

        var allPages = table.cells().nodes();
        // alert('Kakak');
        $("#selectAll").on("click", function () {
            // table.$("input[type='checkbox']").attr('checked', $(this.checked));  
            if (allPages.$("input[type='checkbox']").is(":checked")) {
                allPages.$("input[type='checkbox']").prop('checked', false);
            } else {
                allPages.$("input[type='checkbox']").prop('checked', $(this.checked));
            }
        });

        function fn(text, count) {
            return text.slice(0, count) + (text.length > count ? "..." : "");
        }

        $('#table tfoot th').each(function () {
            var title = $(this).text();
            if (title != 'NO')
                $(this).html('<input type="text" class="form-control-sm" placeholder="Search ' + title +
                    '" />');
        });



        // Apply the search
        table.columns().every(function () {
            var that = this;

            $('input', this.footer()).on('keyup change clear', function () {
                if (that.search() !== this.value) {
                    that
                        .search(this.value)
                        .draw();
                }
            });
        });
    });

    $(function () {
        $('#delete_value').click(function () {
            var val = [];
            $(':checkbox:checked.checkItem').each(function (i) {
                val[i] = $(this).val();
            });
            deleteSelectedData(val)
            // console.log(val);
        });
    });


    function deleteSelectedData(ids) {
        $.confirm({

            theme: 'material',
            title: 'Confirm!',
            content: 'Are you sure you want to delete data ?',
            buttons: {
                confirm: function () {
                    $.ajax({
                        url: route_url + '/delete-seleted',
                        dataType: 'json',
                        type: 'POST',
                        
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>",
                            id_many: ids
                        },
                        success: function (data) {
                            location.reload();
                            console.log(data);
                        },
                        error: function (data) {
                            $.alert('Failed!');
                            console.log(data);
                        }
                    });
                },
                cancel: function () {
                    $.alert('Canceled!');
                },
                // somethingElse: {
                //     text: 'Something else',
                //     btnClass: 'btn-blue',
                //     keys: ['enter', 'shift'],
                //     action: function () {
                //         $.alert('Something else?');
                //     }
                // }
            }
        });
    }

    // $("#checkAll").click(function () {
    //     $(':checkbox.checkItem').prop('checked', this.checked);
    // });
    // var allChecked = false;
    //header checkbox click handler
    // document.getElementById('table').addEventListener('click', event => {
    //     if ($(event.target).is('thead [type="checkbox"]')) {
    //         //assign global variable to current state
    //         allChecked = $(event.target).prop('checked');
    //         //trigger table re-draw
    //         //     $(':checkbox.checkItem').prop('checked', this.checked);

    //         $('table').DataTable().draw(false);
    //         //prevent click from propagation and swapping column ordering
    //         event.stopPropagation();
    //     }
    // }, true);

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>