<?php $__env->startSection('page_title',$page_title); ?>


<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
            <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
            <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>
        </nav>
    </div><!-- br-pageheader -->
    

<div class="br-pagebody">

    

    <div class="row   mg-b-20">


        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h6 class="card-title"><?php echo e($page_title); ?></h6>
                </div><!-- card-header -->
                <div class="card-body">
                    <div class="table-wrapper">
                        <table class="table " id="datatable1">
                            <thead>
                                <th>No</th>
                                
                                <th width="30%">Desc</th>
                                <th>Type</th>
                                <th>Unit</th>
                                
                                <th>Qty</th>
                                <th>Warehouse At</th>
                                 
                            </thead>
                            <tbody>
                                <?php
                                $no=1;
                                ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($item->description); ?></td>
                                    <td><?php echo e($item->type); ?></td>
                                    <td><?php echo e($item->unit); ?></td>
                                    <td><?php echo e($item->qty_sum); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    
                                   
                                   

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
 


</div><!-- br-pagebody -->
<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>