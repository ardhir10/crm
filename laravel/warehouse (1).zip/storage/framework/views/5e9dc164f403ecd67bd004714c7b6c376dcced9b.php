<?php $__env->startSection('page_title',$page_title); ?>


<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <div>
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
                <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>

            </nav>

        </div>
    </div><!-- br-pageheader -->


    <div class="br-pagebody">

        <div class="row">

            <div class="col-lg-12 mg-b-20">
                <div class="br-section-wrapper" style="padding: 30px 20px">
                    <div style="align">
                        <span class="tx-bold tx-18"><i class="icon ion ion-ios-people tx-22"></i> <?php echo e($page_title); ?></span>
                        <a href="<?php echo e(url('users/create')); ?>">
                            <button class="btn btn-sm btn-info float-right"><i
                                    class="icon ion ion-ios-plus-outline"></i>
                                New
                                Data</button>
                        </a>
                    </div>
                    <hr>
                    <?php if(session()->has('create')): ?>
                    <div class="alert alert-success wd-50p">
                        <?php echo e(session()->get('create')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('update')): ?>
                    <div class="alert alert-warning wd-50p">
                        <?php echo e(session()->get('update')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>


                    <?php if(session()->has('delete')): ?>
                    <div class="alert alert-danger wd-50p">
                        <?php echo e(session()->get('delete')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                    </div>
                    <?php endif; ?>
                    <div class="table-wrapper ">
                        <table class="table display responsive nowrap" id="datatable1">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Avatar</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Departement</th>
                                    <th width="15%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no=1;
                                ?>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td>
                                        <?php if($user->avatar): ?>
                                        <img class="wd-32 rounded-circle img-profile" src="<?php echo e(asset('backend/images/users/'.$user->avatar)); ?>" alt="profile">
                                        <?php else: ?>
                                        <img class="wd-32 rounded-circle img-profile" src="https://www.ommel.fi/content/uploads/2019/03/dummy-profile-image-male.jpg" alt="profile">
                                        <?php endif; ?>
                                        </td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        
                                        <?php echo e($user->departement['name']); ?>

                                    </td>
                                    <td>
                                       
                                        <a href="<?php echo e(url('users/'.$user->id.'/edit/')); ?>">
                                            <button class="btn btn-warning btn-sm text-white">
                                                <i class="icon icon ion ion-edit"></i> Edit

                                            </button>
                                        </a>
                                        <?php if(Auth::user()->id != $user->id): ?>
                                            <button class="btn btn-danger btn-sm text-white"
                                                onclick="deleteData(<?php echo e($user->id); ?>)">
                                                <i class="icon icon ion ion-ios-trash-outline"></i> Delete
                                            </button>
                                        <?php endif; ?>
                                        
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                    
                </div>

            </div>

        </div>

    </div><!-- br-pagebody -->

    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
    var route_url= 'users'; 
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>