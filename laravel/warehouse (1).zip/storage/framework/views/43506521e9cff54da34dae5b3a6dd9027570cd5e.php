<?php $__env->startSection('page_title',$page_title); ?>


<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
            <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
            <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>
        </nav>
    </div><!-- br-pageheader -->
    

<div class="br-pagebody">

     
 

    <div class="row   mg-b-20">


        <div class="col-lg-4">
            <h6 class="card-title"><?php echo e($page_title); ?></h6>
            <div class="card">
               
                <div class="card-header">
                        
                
                </div><!-- card-header -->
                <div class="card-body">
                    <div class="table-wrapper">
                    <form action="<?php echo e(url($base_route.'/wip')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                           <div class="form-group">
                               <label for="">WIP NUMBER <span class="text-danger">*</span>: </label>
                               <input type="text" class="form-control<?php echo e($errors->has('wip_number') ? ' is-invalid' : ''); ?>" value="<?php echo e($wip_number); ?>" name="wip_number" readonly required>
                           </div>

                           <div class="form-group">
                                <label for="">REQUEST BY : </label>
                                <input type="text" class="form-control<?php echo e($errors->has('request_by') ? ' is-invalid' : ''); ?>" name="request_by">
                            </div>

                            <div class="form-group">
                                <label for="">DESCRIPTION : </label>
                                <textarea  class="form-control"  name="description" id="" cols="30" rows="5"></textarea>
                            </div>

                            <div class="form-group">
                            <a href="<?php echo e(url($base_route.'/wip')); ?>" class="btn  btn-danger"><i class="ion-arrow-left-a"></i> Back</a>
                                <button type="submit" class="btn  btn-teal"><i class="ion-arrow-right-a"></i> Continue Create </button>                                 
                            </div>
                       </form>
                    </div>
                </div>
            </div>
        </div>

    </div>



    


</div><!-- br-pagebody -->
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        var route_url = '<?php echo e(url($base_route)); ?>';


    });

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>