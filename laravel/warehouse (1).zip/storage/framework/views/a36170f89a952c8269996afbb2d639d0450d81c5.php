<?php $__env->startSection('page_title',$page_title); ?>

<?php $__env->startSection('css'); ?>
<style>
    .select2-results__option[aria-selected=true] {
        display: none;
    }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <div w>
            <nav class="breadcrumb pd-0 mg-0 tx-12">
                <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
                <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>

            </nav>

        </div>
    </div><!-- br-pageheader -->


    <div class="br-pagebody">

        <div class="row">

            <div class="col-lg-6 mg-b-20">
                <div class="br-section-wrapper" style="padding: 30px 20px">
                    <div style="align">
                        <span class="tx-bold tx-18"><?php echo e($page_title); ?></span>
                        
                        <hr>
                        <form method="POST" action="<?php echo e(url($base_route.'/store')); ?>">
                        
                            <?php echo csrf_field(); ?>
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <div class="form-group ">
                                <label for="">Description</label><span class="text-danger">*</span>

                                <textarea class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                    name="description" id="" cols="30" rows="3"><?php echo e(old('description')); ?></textarea>

                                <?php if($errors->has('description')): ?>
                                <small class="text-danger"><?php echo e($errors->first('description')); ?></small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group ">
                                <label for="">Type</label>
                                <input type="text" class="form-control<?php echo e($errors->has('type') ? ' is-invalid' : ''); ?>"
                                    name="type" value="<?php echo e(old('type')); ?>">

                                <?php if($errors->has('type')): ?>
                                <small class="text-danger"><?php echo e($errors->first('type')); ?></small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group ">
                                <label for="">MFG</label>
                                <input type="text" class="form-control<?php echo e($errors->has('mfg') ? ' is-invalid' : ''); ?>"
                                    name="mfg" value="<?php echo e(old('mfg')); ?>">

                                <?php if($errors->has('mfg')): ?>
                                <small class="text-danger"><?php echo e($errors->first('mfg')); ?></small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group ">
                                <label for="">QTY</label>
                                <span class="text-danger">*</span>
                                <input type="number" class="form-control<?php echo e($errors->has('qty') ? ' is-invalid' : ''); ?>"
                                    name="qty" value="<?php echo e(old('qty')); ?>">

                                <?php if($errors->has('qty')): ?>
                                <small class="text-danger"><?php echo e($errors->first('qty')); ?></small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group ">
                                <label for="">Unit</label>
                                <span class="text-danger">*</span>
                                <input type="text" class="form-control<?php echo e($errors->has('unit') ? ' is-invalid' : ''); ?>"
                                    name="unit" value="<?php echo e(old('unit')); ?>">

                                <?php if($errors->has('unit')): ?>
                                <small class="text-danger"><?php echo e($errors->first('unit')); ?></small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group ">
                                <label for="">Price</label>
                                <span class="text-danger">*</span>
                                <input type="number"
                                    class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" name="price"
                                    value="<?php echo e(old('price')); ?>">

                                <?php if($errors->has('price')): ?>
                                <small class="text-danger"><?php echo e($errors->first('price')); ?></small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group ">
                                <label for="">Disc</label>
                                <input type="number" class="form-control<?php echo e($errors->has('disc') ? ' is-invalid' : ''); ?>"
                                    name="disc" value="<?php echo e(old('disc')); ?>">

                                <?php if($errors->has('disc')): ?>
                                <small class="text-danger"><?php echo e($errors->first('disc')); ?></small>
                                <?php endif; ?>
                            </div>

                            <div class="form-group ">
                                <label for="">Total Cost</label>
                                <input type="number"
                                    class="form-control<?php echo e($errors->has('total_cost') ? ' is-invalid' : ''); ?>"
                                    name="total_cost" value="<?php echo e(old('total_cost')); ?>">

                                <?php if($errors->has('total_cost')): ?>
                                <small class="text-danger"><?php echo e($errors->first('total_cost')); ?></small>
                                <?php endif; ?>
                            </div>





                            <div class="form-group">
                                <button class="btn   btn-success" type="submit"><i class="far fa-save"></i>
                                    Save</button>
                                <a href="<?php echo e(url($base_route)); ?>"><button class="btn   btn-danger" type="button"><i
                                            class="far fa-arrow-alt-circle-left"></i> Cancel</button></a>

                            </div>
                        </form>
                    </div>
                    <hr>

                </div>

            </div>

        </div>

    </div><!-- br-pagebody -->

    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
    $("#e1").select2();
    $("#checkbox").click(function () {
        if ($("#checkbox").is(':checked')) {
            $("#e1 > option").prop("selected", "selected");
            $("#e1").trigger("change");
        } else {
            $("#e1 > option").removeAttr("selected");
            $("#e1").val("");
            $("#e1").trigger("change");
        }
    });

    $("#button").click(function () {
        alert($("#e1").val());
    });

    $("select").on("select2:select", function (evt) {
        var element = evt.params.data.element;
        var $element = $(element);
        $element.detach();
        $(this).append($element);
        $(this).trigger("change");
    });

</script>

<?php if(old('privileges')): ?>
<script>
    $("#e1").val([
        <?php $__currentLoopData = old('privileges'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privilege_selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
            !!$privilege_selected!!
        },
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    ]);

</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>