<?php $__env->startSection('page_title',$page_title); ?>


<?php $__env->startSection('content'); ?>
<div class="br-mainpanel">
    <div class="br-pageheader">
        <nav class="breadcrumb pd-0 mg-0 tx-12">
            <a class="breadcrumb-item" href="index.html"><?php echo e(config('app.name')); ?></a>
            <span class="breadcrumb-item active"><?php echo e($page_title); ?></span>
        </nav>
    </div><!-- br-pageheader -->
    

<div class="br-pagebody">

    <div class="row  mg-b-20">


        <div class="col-lg-12">
            <div class="row">

                <div class="col-lg-3 ">
                    <div class="card card-body tx-white-8 bg-transfile bd-0 rounded-10 mg-b-20">
                        <div class="  d-flex align-items-center">
                            
                            <img src="<?php echo e(asset('icons/other/icons8_purchase_order_64px.png')); ?>" class="img-fluid" alt="">

                            <div class="mg-l-20">
                                <p class="tx-10 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">
                                    Purchase Orders</p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?php echo e($po->count()); ?></p>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-3 ">
                    <div class="card card-body tx-white-8 bg-success bd-0 rounded-10 mg-b-20">
                        <div class="  d-flex align-items-center">
                            
                            <img src="<?php echo e(asset('icons/other/icons8_exit_64px.png')); ?>" class="img-fluid" alt="">
                            <div class="mg-l-20">
                                <p class="tx-10 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">
                                    Items In</p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?php echo e($item_in); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 ">
                    <div class="card card-body tx-white-8 bg-danger bd-0 rounded-10 mg-b-20">
                        <div class="  d-flex align-items-center">
                            
                            <img src="<?php echo e(asset('icons/other/icons8_export_64px.png')); ?>" class="img-fluid" alt="">
                            <div class="mg-l-20">
                                <p class="tx-10 tx-spacing-1 tx-mont tx-semibold tx-uppercase tx-white-8 mg-b-10">
                                    Items Out </p>
                                <p class="tx-24 tx-white tx-lato tx-bold mg-b-0 lh-1"><?php echo e($item_out); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                



</div>

</div>

</div>

<div class="row   mg-b-20">

    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
            <h5>Items In at :  <?php echo e(date('F Y')); ?></h5>
                <div class="bd pd-t-30 pd-b-20 pd-x-20"><canvas id="chartBar1" height="100"></canvas></div>
            </div>
        </div>
    </div>

    



</div>

<div class="row   mg-b-20">


    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h6 class="card-title">Purchase Order</h6>
            </div><!-- card-header -->
            <div class="card-body">
                <div class="table-wrapper">
                    <table class="table " id="datatable1">
                        <thead>
                            <th>No</th>
                            
                            <th>PO Number</th>
                            
                            <th>PR Number</th>
                            <th>Delivered At</th>
                            <th>Warehouse At</th>
                            <th>Status</th>
                            <th> items</th>
                            <th>Project</th>
                        </thead>
                        <tbody>
                            <?php
                            $no=1;
                            ?>
                            <?php $__currentLoopData = $last_po; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($no++); ?></td>
                                
                                <td>
                                    <a href="<?php echo e(url('warehouse/purchase-orders/'.$lpo->id.'/items')); ?>">
                                        <p class="mg-b-0"><?php echo e($lpo->po_number); ?></p>
                                    </a>
                                </td>
                                
                                <td> <a
                                        href="<?php echo e(url('purchase-requisitions/'.$lpo->pr->id.'/items')); ?>"><?php echo e($lpo->pr->pr_number); ?></a>
                                </td>
                                <td>
                                    <?php echo e($lpo->delivered_at); ?>

                                </td>

                                <td>
                                    <?php echo e($lpo->warehouse_at); ?>

                                </td>
                                <td>
                                    <?php if($lpo->status == 0): ?>
                                    <span class="btn btn-danger btn-sm rounded-10"> <i class="icon ion ion-card"></i>
                                        Awaiting Payment</span>
                                    <?php endif; ?>

                                    <?php if($lpo->status == 1): ?>
                                    <span class="btn btn-success btn-sm rounded-10"><i class="fa fa-truck"></i>
                                        Delivered</span>
                                    <?php endif; ?>

                                    <?php if($lpo->status == 2): ?>
                                    <span class="btn btn-dark btn-sm rounded-10"> <i
                                            class="icon ion ion-ios-home-outline"></i> Warehouse</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($lpo->items()->count()); ?>

                                </td>
                                <td>
                                    <small><?php echo e($lpo->pr->project->project_number); ?></small>
                                    <br>
                                    <?php echo e($lpo->pr->project->name); ?>

                                </td>



                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
                
            </div>
        </div>
    </div>

</div>






</div><!-- br-pagebody -->
<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function () {
        var route_url = '<?php echo e(url($base_route)); ?>';

        getData();

        function getData() {
            $.ajax({
                url: route_url + '/trending',
                dataType: 'json',
                type: 'GET',

                success: function (data) {
                    drawChart(data.data.tstamp,data.data.total_item);
                },
                error: function (data) {
                    $.alert('Failed!');
                    console.log(data);
                }
            });
        }

        function drawChart(tstamp,items) {
            var ctx1 = document.getElementById('chartBar1').getContext('2d');
            new Chart(ctx1, {
                type: 'line',
                data: {
                    labels: tstamp,
                    datasets: [{
                            // lineTension: 0,
                            label: 'Total Item',
                            data: items,
                            backgroundColor: '#17A2B8',
                            borderColor: '#17A2B8',
                            borderWidth: 3,
                            fill: false
                        },
                        
                    ]
                },
                options: {
                    responsive: true,
        scaleBeginAtZero: false,
                    legend: {
                        display: true,
                        position: 'top',
                        labels: {
                            fontColor: "#000000",
                        }
                    },
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: true,
                                fontSize: 10,
                                // max: 100,
                                // max: Math.max.apply(this, items) + 5,
                                // stepSize: 20
                            }
                        }],
                        xAxes: [{
                            ticks: {
                                beginAtZero: true,
                                fontSize: 11
                            }
                        }]
                    }
                }
            });
        }



        // var pieData = [{
        //     name: 'Purchase Order',
        //     type: 'pie',
        //     radius: '50%',
        //     center: ['50%', '50.5%'],
        //     data: [{
        //             value: 335,
        //             name: 'Awaiting',
        //             itemStyle: {
        //                 color: '#DC3545'
        //             },
        //         },
        //         {
        //             value: 310,
        //             name: 'Delivered',
        //             itemStyle: {
        //                 color: '#23BF08'
        //             },
        //         },
        //         {
        //             value: 234,
        //             name: 'Warehouse',
        //             itemStyle: {
        //                 color: '#2E363E'
        //             },
        //         },

        //     ],
        //     label: {
        //         normal: {
        //             fontFamily: 'Roboto, sans-serif',
        //             fontSize: 11
        //         }
        //     },
        //     labelLine: {
        //         normal: {
        //             show: false
        //         }
        //     },
        //     markLine: {
        //         lineStyle: {
        //             normal: {
        //                 width: 1
        //             }
        //         }
        //     }
        // }];

        // var pieOption = {
        //     tooltip: {
        //         trigger: 'item',
        //         formatter: '{a} <br/>{b}: {c} ({d}%)',
        //         textStyle: {
        //             fontSize: 11,
        //             fontFamily: 'Roboto, sans-serif'
        //         }
        //     },
        //     series: pieData
        // };

        // var pie = document.getElementById('chartPie');
        // var pieChart = echarts.init(pie);
        // pieChart.setOption(pieOption);
    });

</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>